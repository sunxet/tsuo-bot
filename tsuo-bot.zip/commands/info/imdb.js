const discord = require("discord.js");
const fetch = require("node-fetch")

module.exports = {
name: "imdb",
  description: "Obtenha as informações sobre séries e filmes",
  category: "info",
  usage: "imdb <nome>",
  run: async (client, message, args, color) => {
    
    if(!args.length) {
      return message.channel.send("Por favor, dê o nome do filme ou série")
    }


    let msg = await message.channel.send({embed: {
      "description": "Obtendo a informação...",
      "color": "YELLOW"
    }})

    
    try {
    let movie = await fetch(`https://www.omdbapi.com/?apikey=5e36f0db&t=${args.join("+")}`)
    movie = await movie.json()

    if(!movie.Responce) return msg.edit({
        embed: {
          "description": "Incapaz de encontrar algo sobre `" + args.join(" ") + "`",
          "color": "RED"
        }
      })
    
    let embed = new discord.MessageEmbed()
    .setTitle(movie.Title)
    .setColor("GREEN")
    .setThumbnail(movie.Poster)
    .setDescription(movie.Plot)
    .setFooter(`Avaliações: ${movie.imdbRating} | Temporadas: ${movie.totalSeasons || "0"}`)
    .addField("País", movie.Country, true)
    .addField("Linguas", movie.Language, true)
    .addField("Tipo", movie.Type, true);
    
    
    msg.edit(embed)
    } catch(err) {
      msg.edit({
        embed: {
          "description": "Algo deu errado :/",
          "color": "RED"
        }
      })
    }
    
    
  }

}