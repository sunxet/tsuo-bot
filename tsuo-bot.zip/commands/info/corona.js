const discord = require("discord.js")
const fetch = require("node-fetch")

module.exports = {
  name: "corona",
  category: "info",
  description: "Obtenha as estatísticas da corona",
  usage: "corona all ou corona <país>",
  aliases: ["covid", "covid19"],
  run: async (client, message, args) => {
  



let msg = await message.channel.send({
  embed: {
    "description": "Obtendo as informações....",
    "color": "YELLOW"
  }
})
    
   
    if(!args[0] || args[0].toLowerCase() === "all" || args[0].toLowerCase() === "global") {
       try {
      let corona = await fetch("https://disease.sh/v3/covid-19/all")
      corona = await corona.json()
      
      let embed = new discord.MessageEmbed()
      .setTitle("Casos globais")
      .setColor("GREEN")
      .setDescription("Às vezes, o número de casos pode ser diferente de uma pequena quantidade.")
      .addField("Casos Totais", corona.cases, true)
      .addField("Mortes Totais", corona.deaths, true)
      .addField("Total Recuperado", corona.recovered, true)
      .addField("Casos de Hoje", corona.todayCases, true)
      .addField("Mortes de Hoje", corona.todayDeaths, true)
      .addField("Casos Ativos", corona.active, true);
      
     
      return msg.edit(embed)
      } catch(err) {
    
    msg.edit({embed: {
      
      "description": "Algo deu errado :/",
      "color": "RED"
    }})
  }
      
      
    } else {

       try {

      let corona = await fetch(`https://disease.sh/v3/covid-19/countries/${args.join(" ")}`)
      corona = await corona.json()
      
      let embed = new discord.MessageEmbed()
      .setTitle(`${corona.country.toUpperCase()}`)
      .setColor("GREEN")
      .setDescription("Às vezes, o número de casos pode ser diferente de uma pequena quantidade.")
      .setThumbnail(corona.countryInfo.flag || "")
      .addField("Casos Totais", corona.cases, true)
      .addField("Mortes Totais", corona.deaths, true)
      .addField("Total Recuperado", corona.recovered, true)
      .addField("Casos de Hoje", corona.todayCases, true)
      .addField("Mortes de Hoje", corona.todayDeaths, true)
      .addField("Casos Ativos", corona.active, true);
      
      return msg.edit(embed)

      } catch(err) {
    
    msg.edit({embed: {
      
      "description": "Não foi possível encontrar as informações relacionadas a determinado país!",
      "color": "RED"
    }})
  }
      
      
    }
    
  

  }
}