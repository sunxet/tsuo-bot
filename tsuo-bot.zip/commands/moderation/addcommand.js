const db = require("quick.db")

module.exports = {
  name: "addcmd",
  usage: "addcmd <nome> <resposta>",
  description: "adicionar comandos personalizados no servidor",
  category: "moderation",
  run: (client, message, args) => {


    if(!message.member.hasPermission("MANAGE_MESSAGES")) return message.channel.send(":x: Você precisa de permissões `MANAGE_MESSAGES` para usar este comando")

    let cmdname = args[0]

    if(!cmdname) return message.channel.send(`:x: Você deve fornecer o nome do comando, \`addcmd <nome> <resposta>\``)

    let cmdresponce = args.slice(1).join(" ")

    if(!cmdresponce) return message.channel.send(`:x: Você tem que dar uma resposta de comando cmd, \`addcmd <nome> <resposta>\``)

    let database = db.get(`cmd_${message.guild.id}`)

    if(database && database.find(x => x.name === cmdname.toLowerCase())) return message.channel.send(":x: Este nome de comando já foi adicionado aos comandos personalizados do servidor.")

    let data = {
      name: cmdname.toLowerCase(),
      responce: cmdresponce
    }

    db.push(`cmd_${message.guild.id}`, data)

    return message.channel.send("Adicionado **" + cmdname.toLowerCase() + "** como um comando personalizado.")


  }
}