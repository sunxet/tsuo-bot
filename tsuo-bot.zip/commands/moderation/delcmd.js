const db = require("quick.db")

module.exports = {
  name: "delcmd",
  usage: "delcmd <nome>",
  description: "Exclua o comando personalizado",
  category: "moderation",
  run: (client, message, args) => {

    let cmdname = args[0]

    if(!cmdname) return message.channel.send(":x: Dê-me o nome do comando, `delcmd <nome>`")

    let database = db.get(`cmd_${message.guild.id}`)

    if(database) {
      let data = database.find(x => x.name === cmdname.toLowerCase())

      if(!data) return message.channel.send(":x: Incapaz de encontrar este comando.")

      let value = database.indexOf(data)
      delete database[value]

      var filter = database.filter(x => {
        return x != null && x != ''
      })

      db.set(`cmd_${message.guild.id}`, filter)
      return message.channel.send(`Excluído o comando ** $ {cmdname} **!`)


    } else {
      return message.channel.send(":x: Desculpe, mas não consigo encontrar esse comando!")
    


  }
  }
}
 