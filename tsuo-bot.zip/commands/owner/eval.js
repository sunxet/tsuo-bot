const db = require("quick.db")
const Discord = require("discord.js")
const { inspect } = require("util")

module.exports = {
  name: "eval",
  category: "owner",
  ownerOnly: true,
  run: async (client, message, args) => {

    const code = args.slice(0).join(" ")
    if (!code) return message.channel.send({ embed: { description: '❌ Digite algum codigo.!', color: '#00ffff'}});
        
      try {
        let ev = require('util').inspect(eval(code));
        if (ev.length > 1950) {
          ev = ev.substr(0, 1950);
        }
          message.channel.send({ embed: { description: '✔ Sucesso: \`\`\`js\n' + ev + '\n\`\`\`', color: 'GREEN' }});
        } catch(err) {
          message.channel.send({ embed: { description: '❌ Erro: ```' + err + '```', color: '#00ffff'}});
      }
    }
}