const db = require("quick.db")
const discord = require("discord.js")

module.exports = {
  name: "status",
  description: "Mude o status do bot",
  usage: "status <;-;>",
  category: "owner",
  ownerOnly: true,
  run: async (client, message, args) => {
    
  
    //ARGUMENT
    if(!args.length) {
      return message.channel.send("Diga o status cbç de pika")
    }
    
 db.set(`status`, args.join(" "))
 client.user.setActivity(args.join(" ")); 
 message.channel.send("Status atualizado")

    
  }
}