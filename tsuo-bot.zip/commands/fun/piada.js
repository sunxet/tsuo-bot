const { Random } = require("something-random-on-discord")
const random = new Random();
 
module.exports = {
  name: "piada",
   category: "fun",
  
  description: "Piada fresca :D",
run: async (client, message, args) => {
  
    let data = await random.getJoke()
    message.channel.send(data)
  
}
}