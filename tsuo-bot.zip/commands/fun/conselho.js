const { Random } = require("something-random-on-discord")
const random = new Random();
 
module.exports = {
  name: "conselho",
   category: "fun",
   
  description: "Obtenha novos conselhos :D",
run: async (client, message, args) => {
  
    let data = await random.getAdvice()
    message.channel.send(data)
  
}
}