const { MessageEmbed } = require("discord.js")


module.exports = {
  name: "suggest",
  usage: "suggest <menssagem>",
  description: "Envie sua sugestão",
  category: "main",
  run: (client, message, args) => {
    
    if(!args.length) {
      return message.channel.send("Por favor, dê a sugestão")
    }
    
    let channel = message.guild.channels.cache.find((x) => (x.name === "sugestões" || x.name === "๑‧˚₊꒷🍁・sugestões"))
    
    
    if(!channel) {
      return message.channel.send("não há canal de sugestões")
    }
                                                    
    
    let embed = new MessageEmbed()
    .setAuthor("SUGESTÃO: " + message.author.tag, message.author.avatarURL())
    .setThumbnail(message.author.avatarURL())
    .setColor("#ff2050")
    .setDescription(args.join(" "))
    .setTimestamp()
    
    
    channel.send(embed).then(m => {
      m.react("✅")
      m.react("❌")
    }).catch(err => {})
    

    
    message.channel.send("Enviou sua sugestão para " + channel).catch(err => {})
    
  }
}