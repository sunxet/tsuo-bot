const db = require("quick.db")

module.exports.run = (client) => {
  console.log("Tsuo log")
  client.user.setActivity(db.get(`status`)); 
}